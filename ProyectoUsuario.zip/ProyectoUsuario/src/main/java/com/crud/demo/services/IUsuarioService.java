package com.crud.demo.services;

import java.util.List;

import com.crud.demo.entity.Usuario;

public interface IUsuarioService {

	// Metodo para listar todos los usuarios.
	public List<Usuario> listarTodo();

	// Metodo para guardar o actualizar un usuario.
	public Usuario save(Usuario usuarios);

	// Metodo para buscar un usuario por su ID.
	public Usuario buscarPorID(Long id);

	// Metodo para eliminar un usuario por su ID.
	public void Eliminar(Long id);
	
    public Usuario crearUsuario(String nombre, String clave, String email, Boolean estado); 

}
