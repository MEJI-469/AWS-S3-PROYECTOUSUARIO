package com.crud.demo.factory;

import org.springframework.stereotype.Component;

import com.crud.demo.entity.Usuario;

@Component
public class UsuarioFactoryImpl implements UsuarioFactory {

    @Override
    public Usuario crearUsuario(String nombre, String clave, String email, Boolean estado) {
        return new Usuario(nombre, clave, email, estado);
    }
}
