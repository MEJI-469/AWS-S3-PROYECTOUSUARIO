package com.crud.demo.factory;

import com.crud.demo.entity.Usuario;

public interface UsuarioFactory {
	
	 Usuario crearUsuario(String nombre, String clave, String email, Boolean estado);

}
