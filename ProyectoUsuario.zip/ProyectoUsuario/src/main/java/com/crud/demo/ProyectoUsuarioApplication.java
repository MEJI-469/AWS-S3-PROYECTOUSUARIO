package com.crud.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoUsuarioApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoUsuarioApplication.class, args);
	}

}
